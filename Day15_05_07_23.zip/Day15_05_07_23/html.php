<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Html | php</title>
</head>
<body>
    <?php
echo"Hello world\n";
echo 1000 + 20000;
echo 5000+5000;
echo"karan chauhan";
?>

    
</body>
</html>