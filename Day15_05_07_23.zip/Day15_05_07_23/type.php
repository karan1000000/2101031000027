<?php

    $a="123.abc";
    echo "Type of a is :".gettype($a)."<br>";
    settype($a,"int");
    echo"after conversion type of a is :".gettype($a);
?>