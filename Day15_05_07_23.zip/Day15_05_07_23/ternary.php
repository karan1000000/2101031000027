<?php
    $a =15;
    $b=45;
    $c=60;

    // echo($a>$b)?("<br>".$a."is grater"):("<br>".$b."is grater");
    if($a > $b)
    {

        if($a>$c ){
            echo"<br>".$a."is grater";
        }
        else{
            echo"<br>".$c."is grater";
    
        }
    }
    else{
        if($b>$c ){
            echo"<br>".$b."is grater";
        }
        else{
            echo"<br>".$c."is grater";
    
        }

    }



?>
