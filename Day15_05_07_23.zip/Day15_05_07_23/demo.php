<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    print"Hello" . "<br>";
    print "how r u" . "<br>";
    print "how r u jaival"."<br>";

    $a=10;
    $b=5;
    $add=$a+$b;
    $sub=$a-$b;
    $div=$a/$b;
    $mul=$a*$b;
    echo"value of a is 10:".$a;
    echo"<br>";
    echo"Adiition of two number is :".$add;
    echo"<br>";
    echo"substraction of two number is :".$sub;
    echo"<br>";
    echo"Division of two number is :".$div;
    echo"<br>";
    echo"Multiplication of two number is :".$mul."<br>";

    $r="123.abc"."<br>";

    echo "Type of a is :".gettype($a);
    ?>
</body>
</html>