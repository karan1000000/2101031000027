<?php
    $i=1;

    for($i=1;$i<=10;$i++)
    {
        echo"$i"."<br>";
    }
?>