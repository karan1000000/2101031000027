<?php
    $i=1;
    while($i<=10)
    {
        echo "2 x ".$i."=".(2*$i)."<br>";
        $i++;
    }
?>