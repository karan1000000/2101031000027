<?php
    // $a=array(1,3,4,5,6,7,8);
    
    // print_r($a);
    // $sum=0;
    // foreach($a as $value){
    //     $sum=$sum + $value;

    // }
    // echo "<br>".$sum;
?>