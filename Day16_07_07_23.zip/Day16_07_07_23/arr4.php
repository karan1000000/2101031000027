<?php

$a =array("xyz","abc","def");
print_r($a);
echo"<br>";

$merge = array_reverse($a);
print_r($merge);

echo count($a);
?>
