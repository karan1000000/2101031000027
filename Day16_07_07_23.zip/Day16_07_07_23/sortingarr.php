<?php
$b=array("xyz","abc","def");
print_r($b);
sort($b);
echo"<br>"."after sorting "."<br>";
print_r($b);

?>
