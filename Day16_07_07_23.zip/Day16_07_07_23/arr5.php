<?php
        $a=array("xyz"=>12,"ABC"=>22,"JKL"=>18);

        print_r($a);

?>
