var fullNameRegEx = /^([a-zA-Z ]{2,40})+$/;
var conNoRegEx = /^([0-9]{10})$/;
var emailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;

document.addEventListener('DOMContentLoaded', function () {


    // First name  ..................................

    var nameInput = document.getElementById('TxtFirstname123');
    var nameValidation = document.getElementById('nameValidation');

    nameInput.addEventListener('blur', function () {
        nameValidation.innerHTML = '';
        if (nameInput.value == '' || nameInput.value == null) {
            nameValidation.innerHTML = '(*) Name Required..!!';
        }
        else {
            if (!nameInput.value.match(fullNameRegEx)) {
                nameValidation.innerHTML = '(*) Invalid Name..!!';
            }
        }
    });

    nameInput.addEventListener('keypress', function (e) {
        nameValidation.innerHTML = '';
        var flag = ((e.which >= 65 && e.which <= 90) || (e.which >= 97 && e.which <= 122));
        if (flag == false) {
            nameValidation.innerHTML = '(*) Invalid Name..!!';
        }
        return flag;
    });


    // last name validation...............................


    var nameInput1 = document.getElementById('TxtLastname123');
    var nameValidation1 = document.getElementById('Lastnamevalidation');

    nameInput1.addEventListener('blur', function () {
        nameValidation1.innerHTML = '';
        if (nameInput1.value == '' || nameInput1.value == null) {
            nameValidation1.innerHTML = '(*) Name Required..!!';
        }
        else {
            if (!nameInput1.value.match(fullNameRegEx)) {
                nameValidation1.innerHTML = '(*) Invalid Name..!!';
            }
        }
    });

    nameInput1.addEventListener('keypress', function (e) {
        nameValidation1.innerHTML = '';
        var flag = ((e.which >= 65 && e.which <= 90) || (e.which >= 97 && e.which <= 122));
        if (flag == false) {
            nameValidation1.innerHTML = '(*) Invalid Name..!!';
        }
        return flag;
    });


    // contact no.....................................

    var contactInput = document.getElementById('contact123');
    var contactValidation = document.getElementById('contactValidation');

    contactInput.addEventListener('blur', function () {
        contactValidation.innerHTML = '';
        if (contactInput.value == '' || contactInput.value == null) {
            contactValidation.innerHTML = '(*) Contact Number Required..!!';
        }
        else {
            if (!contactInput.value.match(conNoRegEx)) {
                contactValidation.innerHTML = '(*) Invalid Contact Number..!!';
            }
        }
    });

    contactInput.addEventListener('keypress', function (e) {
        contactValidation.innerHTML = '';
        var flag = ((e.which >= 48 && e.which <= 57));
        if (flag == false) {
            contactValidation.innerHTML = '(*) Invalid Contact Number..!!';
        }
        return flag;
    });


    // Email id........................................



    var emailInput = document.getElementById('TxtEmail123');
    var emailValidation = document.getElementById('TxtLastnameValidate');

    emailInput.addEventListener('blur', function () {
        emailValidation.innerHTML = '';
        if (emailInput.value == '' || emailInput.value == null) {
            emailValidation.innerHTML = '(*) Email Required..!!';
        }
        else {
            if (!emailInput.value.match(emailIdRegEx)) {
                emailValidation.innerHTML = '(*) Invalid Email..!!';
            }
        }
    });

    // text area.................................

    var msgInput = document.getElementById('msg123');
    var msgValidation = document.getElementById('msgValidation');

    msgInput.addEventListener('blur', function () {
        msgValidation.innerHTML = '';
        if (msgInput.value == '' || msgInput.value == null) {
            msgValidation.innerHTML = '(*) Message Required..!!';
        }
        else {
            if (msgInput.value.length > 300) {
                msgValidation.innerHTML = '(*) Invalid Message..!!';
            }
        }
    });

    // submit......................................

    var btnSubmit = document.getElementById('btnSubmit');

    btnSubmit.addEventListener('click', function () {
        nameValidation.innerHTML = '';
        if (nameInput.value == '' || nameInput.value == null) {
            nameValidation.innerHTML = '(*) Name Required..!!';
            nameFlag = false;
        }
        else {
            if (!nameInput.value.match(fullNameRegEx)) {
                nameValidation.innerHTML = '(*) Invalid Name..!!';
                nameFlag = false;
            }
            else {
                nameFlag = true;
            }
        }

        contactValidation.innerHTML = '';
        if (contactInput.value == '' || contactInput.value == null) {
            contactValidation.innerHTML = '(*) Contact Number Required..!!';
            contactFlag = false;
        }
        else {
            if (!contactInput.value.match(conNoRegEx)) {
                contactValidation.innerHTML = '(*) Invalid Contact Number..!!';
                contactFlag = false;
            }
            else {
                contactFlag = true;
            }
        }

        emailValidation.innerHTML = '';
        if (emailInput.value == '' || emailInput.value == null) {
            emailValidation.innerHTML = '(*) Email Required..!!';
            emailFlag = false;
        }
        else {
            if (!emailInput.value.match(emailIdRegEx)) {
                emailValidation.innerHTML = '(*) Invalid Email..!!';
                emailFlag = false;
            }
            else {
                emailFlag = true;
            }
        }

        msgValidation.innerHTML = '';
        if (msgInput.value == '' || msgInput.value == null) {
            msgValidation.innerHTML = '(*) Message Required..!!';
            msgFlag = false;
        }
        else {
            if (msgInput.value.length > 300) {
                msgValidation.innerHTML = '(*) Invalid Message..!!';
                msgFlag = false;
            }
            else {
                msgFlag = true;
            }
        }

        if (nameFlag == true && contactFlag == true && emailFlag == true && msgFlag == true) {
            nameInput.value = '';
            contactInput.value = '';
            emailInput.value = '';
            msgInput.value = '';
            alert('Form submitted successfully...');
        }
        else {
            alert('Invalid input...');
        }
    });
    
    function submitForm() {
      var value = document.getElementById("inputValue").value;

      if (value !== "") {
        // Submit the form or perform other actions
        document.getElementById("myForm").submit();
      } else {
        // Display an alert if the value is empty
        alert("Please enter a value!");
      }
    }

});