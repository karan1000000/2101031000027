<?php
$first=$_POST['fname'];
$last=$_POST['lname'];
$email=$_POST['email'];
$contact=$_POST['contact'];
$feed=$_POST['msg'];

// echo $first.$last.$email.$contact.$feed;



$servername="localhost";
$usename="root";
$password="";
$dbname="database";

$conn=mysqli_connect($servername,$usename,$password,$dbname);
if(!$conn)
{
    die("Connection failed".mysqli_connect_error());
}
//  else{
//      echo"connect sucessfully";
// }

$sql  = "INSERT INTO database23(firstname,lastname,email,contact,feedback) VALUES ('$first','$last','$email','$contact','$feed') ";
    if(mysqli_query($conn,$sql)){
        echo "Data Inserted";
    }
    else{
        echo "error";
    }




?>
