function demoInternalAlert()
        {
            alert("Internal Alert");
        }
        function demoInternalConfirm()
        {
            if(confirm("Are You Sure...?")){
                alert("Yessss")
            }
            else{
                alert("Nooooooo")
            }
            
        }
        function demoInternalPrompt(){
            var  fname=prompt("Enter First Name");
            var  lname=prompt("Enter Last Name");
            alert(fname+" "+lname);
        }
        
        function demoExternalAlert()
        {
            alert("Internal Alert");
        }
        function demoExternalConfirm()
        {
            if(confirm("Are You Sure...?")){
                alert("Yessss")
            }
            else{
                alert("Nooooooo")
            }
            
        }
        function demoExternalPrompt(){
            var  fname=prompt("Enter First Name");
            var  lname=prompt("Enter Last Name");
            alert(fname+" "+lname);
        }

       function bodyBgGreen(){
        document.body.style.backgroundColor="Green";
       }
       function bodyBgGray(){
        document.getElementById("D1").style.backgroundColor="Gray";
       }
       function bodyBgDaynamic(){
        document.body.style.backgroundColor=prompt("Enter The Colour Name");
       }
       function divBgdaynamic(){
        document.getElementById("D1").style.backgroundColor=prompt("Enter The COlour");
       }
       function bodyBGCP1(){
        document.body.style.backgroundColor=document.getElementById("CP1").value;
       }
       function divBGP2(){
        document.getElementById("D1").style.backgroundColor=document.getElementById("CP2").value;

       }
       function demo1(){
        var one=prompt("Enter First Number =");
        var two=prompt("Enter Second Number =");

        if(one>two){
            alert(one + " IS greater Than "+two);
        }
        else{
            alert(two + " IS greater Than "+one)

        }
       }
       function demo2(){
        var num=prompt("Enter Radius...=");
        
        alert("Area of Circle is "+(3.14*num*num))
       }