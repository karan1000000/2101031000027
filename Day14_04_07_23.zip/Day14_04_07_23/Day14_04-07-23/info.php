<?php
    $name = "Harsh Gandhi";
    $dept = "Information Technology";
    $enroll = 2101031000055;

    echo $name;
    echo "<br>";
    echo $dept;
    echo "<br>";
    echo $enroll;
?>