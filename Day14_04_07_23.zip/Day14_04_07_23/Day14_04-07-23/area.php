<?php
    $r = 5;
    $pi = 3.14;
    $a = $pi*$r*$r;
    echo "Area of circle with radius ", $r , " is : " , $a;
    echo "<br>";
    $l = 10;
    $b = 20;
    $ar = $l * $b;
    echo "Area of rectangle with side ", $l , " & " , $b , " is : " , $ar;
?>