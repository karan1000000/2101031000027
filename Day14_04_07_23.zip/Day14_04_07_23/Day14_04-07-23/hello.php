<?php
echo "Hello world";
?>